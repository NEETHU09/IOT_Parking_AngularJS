A Pen created at CodePen.io. You can find this one at http://codepen.io/siiron/pen/MYXZWg.

 A simple proof-of-concept for an interface for booking seats on a plane.