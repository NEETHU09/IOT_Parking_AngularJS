var express = require('express');
var credentialsDB=require('../public/models/credentialsDB');
var bookingDB = require('../public/models/bookingDetailsSB');
// var operationDB = require('../public/models/operationsDB')
var router= express.Router();
router.route('/addNewUser')
.post(function(req,res){
  var form = req.body;
  credentialsDB.addingUser(form,function(err,result){
    if(err){
      res.send("sorry error found");
    }
    else{
      res.json(result);
    }
  })
})
router.route('/checkUserCredential')
.get(function(req,res){
  credentialsDB.getAllUser(function(err,result){
    if(err){
      res.send("sorry error found");
    }
    else{
      res.json(result);
    }
  })
})
router.route('/getAllBookings/:user')
.get(function(req,res){
  var user = req.params.user;
  bookingDB.getPresentUserBookings(user,function(err,result){
    if(err){
      res.send("sorry error found");
    }
    else{
      res.json(result);
    }
  })
})

router.route('/addBookingDetails')
.post(function(req,res){
  console.log("dadsadada");
  var input = req.body;
  console.log("Inside the  route-----------"+input.bookingOwner);
  bookingDB.addToBookingDB(input,function(err,response){
    if(err){
      res.send("sorry error found");
    }
    else{
      res.json(response);
    }
  })
})
router.route('/getAllBookings')
.get(function(req,res){
  bookingDB.getAllBookingsDB(function(err,result){
    if(err){
      res.send("sorry error found");
    }
    else{
      res.json(result);
    }
  })
})


router.route('/deleteTheBooking/:id')
.delete(function(req,res){
  console.log("inside the routes delete function");
  data = req.params.id;
  console.log(data);
  bookingDB.deleteReserve(data,function(err,result){
    if(err){
      res.send("sorry error found");
    }
    else{
      res.json(result);
    }
  })
})

router.route('/getFilteredTickets')
.post(function(req,res){
  console.log("22222222222222222222222222222");
  console.log(req.body);
  bookingDB.getFilteredTicketsDB(req.body,function(err,result){
    if(err){
      res.send("sorry error found");
    }
    else{
      res.json(result);
    }
  })
})

router.route('/getTodayBookingsRoute')
.post(function(req,res){
  console.log("body : "+req.body);
  var filtObj = req.body;
  bookingDB.getTodayBookingsDB(filtObj,function(err,result){
    if(err){
      res.send("sorry error found");
    }
    else{
      res.json(result);
    }
  })
})

router.route('/getWeeklyBookingsRoute/:bookingType')
.get(function(req,res){
  var bookingType = req.params.bookingType;
  console.log("roter booking type "+bookingType);
  bookingDB.getWeekBookingsDB(bookingType,function(err,result){
    if(err){
      res.send("sorry error found");
    }
    else{
      res.json(result);
    }
  })
})

router.route('/getMonthBookingsRoute/:bookingType')
.get(function(req,res){
  var bookingType = req.params.bookingType;
  console.log("roter booking type "+bookingType);
  bookingDB.getMonthBookingsDB(bookingType,function(err,result){
    if(err){
      res.send("sorry error found");
    }
    else{
      res.json(result);
    }
  })
})
module.exports = router;
