var mongoose = require('mongoose');
var schema= mongoose.Schema;
var BookingDetailsSchema = new schema({
  BookingOwner : String,
  BookingType: String,
  Area : String,
  Tower:String,
  Floor:String,
  Wing:String,
  Zone:String,
  Room:String,
  BookingDate:String,
  StartTime:String,
  EndTime:String,
  SeatNumber:String,
  TypeOfSeater:String
});

var bookingDetailsModel = mongoose.model('bookingDetailsSB',BookingDetailsSchema,'bookingDetailsCollectionSB');
var booking = {};
console.log("inside the SB schema ");
booking.addToBookingDB = function(input,callback){
  var newBook  = new bookingDetailsModel(input);
  return newBook.save(callback);
}
booking.getAllBookingsDB = function(callback){
  bookingDetailsModel.find({},callback);
}
booking.deleteReserve = function(data,callback) {
    console.log("object id is "+data);
    bookingDetailsModel.findOneAndRemove({'_id':data},callback);
}
booking.getFilteredTicketsDB = function(data,callback){
  console.log("3333333333333333333333333333333");
  console.log(data);
  var bookingType = data.bookingType;
  console.log(bookingType);
  var Area = data.Area;
  var Tower = data.Tower;
  var Floor = data.Floor;
  var Wing = data.Wing;
  if((data.Tower != undefined || data.Tower != null) && (data.Floor !=undefined || data.Floor !=null) && (data.Wing !=undefined || data.Wing !=null) ){
      bookingDetailsModel.find({'BookingType':bookingType,'Area':Area,'Tower':Tower,'Floor':Floor,'Wing':Wing},callback);
  }
  else if( (data.Tower != undefined || data.Tower != null) && (data.Floor !=undefined || data.Floor != null) && (data.Wing ==undefined || data.Wing == null) ){
    bookingDetailsModel.find({'BookingType':bookingType,'Area':Area,'Tower':Tower,'Floor':Floor},callback);
  }
  else if( (data.Tower != undefined || data.Tower != null) && (data.Floor ==undefined || data.Floor == null) && (data.Wing !=undefined || data.Wing != null) ){
    bookingDetailsModel.find({'BookingType':bookingType,'Area':Area,'Tower':Tower,'Wing':Wing},callback);
  }
  else if( (data.Tower != undefined || data.Tower != null) && (data.Floor ==undefined || data.Floor == null) && (data.Wing ==undefined || data.Wing == null) ){
    bookingDetailsModel.find({'BookingType':bookingType,'Area':Area,'Tower':Tower,'Tower':Tower},callback);
  }
  else if( (data.Tower == undefined || data.Tower == null) && (data.Floor !=undefined || data.Floor != null) && (data.Wing !=undefined || data.Wing != null) ){
    bookingDetailsModel.find({'BookingType':bookingType,'Area':Area,'Floor':Floor,'Wing':Wing},callback);
  }
  else if( (data.Tower == undefined || data.Tower == null) && (data.Floor !=undefined || data.Floor != null) && (data.Wing ==undefined || data.Wing == null) ){
    bookingDetailsModel.find({'BookingType':bookingType,'Area':Area,'Floor':Floor},callback);
  }
  else if( (data.Tower == undefined || data.Tower == null) && (data.Floor ==undefined || data.Floor == null) && (data.Wing !=undefined || data.Wing != null) ){
    bookingDetailsModel.find({'BookingType':bookingType,'Area':Area,'Wing':Wing},callback);
  }
  else if( (data.Tower == undefined || data.Tower == null) && (data.Floor ==undefined || data.Floor == null) && (data.Wing ==undefined || data.Wing == null) ){
    console.log("");
    bookingDetailsModel.find({'BookingType':bookingType,'Area':Area},callback);
  }
}
booking.getPresentUserBookings = function(user,callback){
  bookingDetailsModel.find({'BookingOwner':user},callback);
}
booking.getTodayBookingsDB = function(filtObj,callback){
  console.log("filtObj.date : "+filtObj.date);

 bookingDetailsModel.find({'BookingDate':filtObj.date,'BookingType':filtObj.bookingType},callback);
}
booking.getWeekBookingsDB = function (bookingType,callback) {
  console.log("booking type is "+bookingType);
  bookingDetailsModel.find({'BookingType':bookingType},callback);
}
booking.getMonthBookingsDB = function(bookingType,callback){
  bookingDetailsModel.find({'BookingType':bookingType},callback);
}
module.exports =booking;
