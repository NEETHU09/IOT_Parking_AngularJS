
var appRoute=angular.module("appRoute",['ui.router','ngMaterial']);
appRoute.config(function($stateProvider, $urlRouterProvider) {
  $urlRouterProvider.otherwise('/login');

  $stateProvider.state('login', {
  url: '/login',
  params:{
    showSeat : "true",
    HideBookSeat : "false"
  },
  views:{
    'header':{
      templateUrl: '/templates/newLoginHeader.html'
    },
    'content':{
      templateUrl: '/templates/newLogin.html'
    }
  }
})
.state('logout',{
  url:'/loggedout',
  views:{
    'header':{
      templateUrl: '/templates/headerSB.html'
    },
    'content':{
      templateUrl:'/templates/newLogin.html',
      controller : "logoutCtrl"
    }
  }
})
.state('adminHomePageSB',{
  url:'/adminHomePageSB',
  params:{
    showSeat : "true",
    HideBookSeat : "false",
    param1: "false",
    param2 : "true",
  },
  views:{
    'header':{
      templateUrl: '/templates/headerSB.html'
    },
    'content':{
      templateUrl:'/templates/adminHomePageSB.html'
    }
  }
})
//-----------admin states--------------------
.state('registerUser',{
  url:'/registerUser',
  params:{
    showSeat : "true",
    HideBookSeat : "false"
  },
  views:{
    // 'header':{
    //   templateUrl: '/templates/headerSB.html'
    // },
    'content':{
      templateUrl:'/templates/registerUser.html'
    }
  }
})
//---------------user states-----------------
.state('bookSeat',{
  url:'/bookSeat',
  params:{
    param1: "true",
    param2 : "true",
    showSeat : "false",
    HideBookSeat : "true"
},
  views:{
    'header':{
      templateUrl:'/templates/headerSB.html'
    },
    'content':{
      templateUrl:'/templates/bookSeat.html',

    }
  }
})
.state('bookingDetailsSB',{
  url:'/bookingDetailsSB/:param1/:param2',
  params:{
    showSeat : "false",
    HideBookSeat : "true"
  },
  views:{
    'header':{
      templateUrl:'/templates/headerSB.html'
    },
    'content':{
      templateUrl:'/templates/bookingDetailsSB.html'
    }
  }
})
.state('ticketsViewSB',{
  url:'/ticketsViewSB/:bookingType',
  // params:{
  //   showSeat : "false",
  //   HideBookSeat : "true"
  // },
  params:{
    showSeat : "true",
    HideBookSeat : "false",
    param1: "false",
    param2 : "true",
  },
  views:{
    'header':{
      templateUrl:'/templates/headerSB.html'
    },
    'content':{
      templateUrl:'/templates/ticketsViewSB.html'
    }
  }
})
.state('HomePage', {
url: '/HomePage',
params:{
  showSeat : "true",
  HideBookSeat : "false"
},
views:{
  'header':{
    templateUrl: '/templates/newLoginHeader.html'
  },
  'content':{
    templateUrl: '/templates/HomePage.html'
  }
}
})
.state('adminHomePage', {
url: '/adminHomePage',
params:{
  showSeat : "true",
  HideBookSeat : "false"
},
views:{
  'header':{
    templateUrl: '/templates/newLoginHeader.html'
  },
  'content':{
    templateUrl: '/templates/adminHomePage.html'
  }
}
})
.state('bookSlot',{
  url:'/bookSlot',
  params:{
    param1: "true",
    param2 : "true",
    showSeat : "false",
    HideBookSeat : "true",
    // param3 : "true"
},
  views:{
    'header':{
      templateUrl:'/templates/headerPA.html'
    },
    'content':{
      templateUrl:'/templates/bookSlot.html',

    }
  }
})
.state('adminHomePagePA',{
  url:'/adminHomePagePA',
  params:{
    showSeat : "true",
    HideBookSeat : "false",
    param1: "false",
    param2 : "true",
    param3 : "true"
  },
  views:{
    'header':{
      templateUrl: '/templates/headerPA.html'
    },
    'content':{
      templateUrl:'/templates/adminHomePagePA.html'
    }
  }
})
.state('bookingDetailsPA',{
  url:'/bookingDetailsPA/:param1/:param2',
  params:{
    showSeat : "false",
    HideBookSeat : "true"
  },
  views:{
    'header':{
      templateUrl:'/templates/headerPA.html'
    },
    'content':{
      templateUrl:'/templates/bookingDetailsPA.html'
    }
  }
})

.state('layoutTemplate',{
  url:'/layoutTemplate/:param1/:param2',
  params:{
    showSeat : "false",
    HideBookSeat : "true"
  },
  views:{
    'header':{
      templateUrl:'/templates/headerPA.html'
    },
    'content':{
      templateUrl:'/templates/layoutTemplate.html'
    }
  }
})
.state('layoutAdminTemplate',{
  url:'/layoutAdminTemplate/:param1/:param2',
  params:{
    showSeat : "true",
    HideBookSeat : "false"
  },
  views:{
    'header':{
      templateUrl:'/templates/headerPA.html'
    },
    'content':{
      templateUrl:'/templates/layoutAdminTemplate.html'
    }
  }
})

});
