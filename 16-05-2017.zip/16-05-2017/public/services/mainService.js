angular.module('appRoute')
.factory('mainService',function($http){
  var currentUser = {};
  function set(data){
    console.log("data"+data);
    currentUser = data;
    console.log("setdata"+currentUser);
  }
   function get(){
     return currentUser;
   }
   function setData(data){
     currentUserBookings = data;
   }
   function getData(){
     return currentUserBookings;
   }

  return{
    set: set,
    get: get,
    registerUser : function(formData){
      // return $http.post('http://localhost:5000/UserRouteSB/addNewUser',formData);
      return $http.post('/UserRouteSB/addNewUser',formData);
    },
    checkCredentials: function(){
        // return $http.get('http://localhost:5000/UserRouteSB/checkUserCredential');
        return $http.get('/UserRouteSB/checkUserCredential');
    },
    addBookingDetailsSB: function(formDetails){
    console.log(formDetails);
        // return $http.post('http://localhost:5000/UserRouteSB/addBookingDetails',formDetails);
        return $http.post('/UserRouteSB/addBookingDetails',formDetails);
    },
    getAllTheBookingsSB :function(){
      // return $http.get('http://localhost:5000/UserRouteSB/getAllBookings');
      return $http.get('/UserRouteSB/getAllBookings');
    },
    getUserBookingsSB: function(user){
        // return $http.get('http://localhost:5000/UserRouteSB/getAllBookings/'+user);
        return $http.get('/UserRouteSB/getAllBookings/'+user);
    },
    saveBookingSeatsSB : function(){
      // return $http.post('http://localhost:5000/UserRouteSB/addBookingSeats');
      return $http.post('/UserRouteSB/addBookingSeats');
    },
    deleteSelectedSB:function(data){
      var id = data._id;
    // return $http.delete('http://localhost:5000/UserRouteSB/deleteTheBooking/'+id);
    return $http.delete('/UserRouteSB/deleteTheBooking/'+id);
  },
  findTicketsWithFilterSB : function(data){
    console.log("@@@@@@@@@@@@@@");
    console.log(data);
    // return $http.post('http://localhost:5000/UserRouteSB/getFilteredTickets',data);
    return $http.post('/UserRouteSB/getFilteredTickets',data);
  },
  getTodayBookingsSB : function(filtObj){
    // return $http.post('http://localhost:5000/UserRouteSB/getTodayBookingsRoute',filtObj);
    return $http.post('/UserRouteSB/getTodayBookingsRoute',filtObj);
  },
  getWeekBookingsSB : function(bookingType){
    console.log("weekly booking ytype "+bookingType);
    // return $http.get('http://localhost:5000/UserRouteSB/getWeeklyBookingsRoute/'+bookingType);
    return $http.get('/UserRouteSB/getWeeklyBookingsRoute/'+bookingType);
    // return $http.post('/UserRouteSB/getWeekBookingsRoute',bookingType);
  },
  getMonthBookingsSB : function(bookingType){
    console.log("weekly booking ytype "+bookingType);
    // return $http.get('http://localhost:5000/UserRouteSB/getMonthBookingsRoute/'+bookingType);
    return $http.get('/UserRouteSB/getMonthBookingsRoute/'+bookingType);
  },

  addBookingDetailsPA: function(formDetails){
  console.log(formDetails);
      // return $http.post('http://localhost:3000/UserRoutePA/addBookingDetails',formDetails);
      return $http.post('/UserRoutePA/addBookingDetails',formDetails);
  },
  getAllTheBookingsPA :function(){
    // return $http.get('http://localhost:3000/UserRoutePA/getAllBookings');
    return $http.get('/UserRoutePA/getAllBookings');
  },
  saveBookingSeatsPA : function(){
    // return $http.post('http://localhost:3000/UserRoutePA/addBookingSeats');
    return $http.post('/UserRoutePA/addBookingSeats');
  },
  deleteSelectedPA:function(data){
    var id = data._id;
  // return $http.delete('http://localhost:3000/UserRoutePA/deleteTheBooking/'+id);
  return $http.delete('/UserRoutePA/deleteTheBooking/'+id);
},
getBookingsPA : function(location,floor){
  console.log("printing location : "+location+" printing floor  : "+floor);
  // return $http.get('http://localhost:3000/UserRoutePA/getBookingsRoute/'+location+'/'+floor);
  return $http.get('/UserRoutePA/getBookingsRoute/'+location+'/'+floor);
},
getLocationBookingPA:function(location,currDate){
  return $http.get('/UserRoutePA/getLocationBookingsRoute/'+location+'/'+currDate);
},
getLocationFloorBookingPA:function(location,floor,currDate){
    return $http.get('/UserRoutePA/getLocationFloorBookingsRoute/'+location+'/'+floor+'/'+currDate);
}
  }
})
