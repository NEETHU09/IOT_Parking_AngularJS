
angular.module('appRoute')
.controller('adminControllerSB',function($window,$scope,$timeout,mainService,$q,$state,$stateParams,$mdDialog,authService){
  // $scope.User = localStorage.getItem("token");
  $scope.logValBD = $stateParams.param1;
  $scope.logValLO = $stateParams.param2;
  $scope.ShowBookSeat = $stateParams.showSeat;
  $scope.HideBookSeat = $stateParams.HideBookSeat;
  $scope.showChartDiv = true;
  // $scope.disableSABtn = false;
  $scope.dbkgShow = true;
  $scope.rbkgShow = false;
  $scope.btnOpacityDB = "1";
  $scope.btnOpacityRB = ".2";
  $scope.tBar = "always";
  $scope.ticketViewBookingType = $stateParams.bookingType;
  $scope.includeDesktopTemplate = false;
  $scope.includeMobileTemplate = false;

  var screenWidth = $window.innerWidth;

  if (screenWidth < 768){
    $scope.includeMobileTemplate = true;
    $scope.tBar = "auto";
  }else{
    $scope.includeDesktopTemplate = true;
    $scope.tBar = "always";
  }


  $scope.showticketViewDetails = function(bookingType){
    // $scope.logValLO = true;
    // $scope.logValBD = false;
    $state.go("ticketsViewSB",{bookingType:bookingType});
  }
  var userObj = authService.getUser();
  if(userObj != undefined){
    var userName = userObj.userName;
    $scope.currentUser = userName.substring(0,1).toUpperCase()+userName.substring(1,userName.length);
    $scope.User = userObj.eMail;
  }
  mainService.getAllTheBookingsSB().success(function(data){
    for (var i = 0; i < data.length; i++) {
      $scope.AllbookingDetails.push(data[i]);
    }
    var len = $scope.AllbookingDetails.length;
  })

  $scope.AllbookingDetails = [];
  $scope.Tower = null;
  $scope.Towers = null;
  // $scope.Areas =['Fareham','Swindon','Cheltenham'];
  $scope.Areas =[{ id: 1, name: 'Fareham' },
  { id: 2, name: 'Swindon' },
  { id: 3, name: 'Cheltenham' }];
  $scope.loadTowers = function() {
    return $timeout(function() {
      $scope.Towers =  $scope.Towers  || [
        { id: 1, name: 'Tower A' },
        { id: 2, name: 'Tower B' }
      ];
    }, 350);
  };
  $scope.Floor = null;
  $scope.Floors = null;
  $scope.loadFloors = function() {
    return $timeout(function() {
      $scope.Floors =  $scope.Floors  || [
        { id: 1, name: 'Ground Floor' },
        { id: 2, name: '1st Floor' },
        { id: 3, name: '2nd Floor' }
      ];
    }, 350);
  };
  $scope.Wing = null;
  $scope.Wings = null;
  $scope.loadWings = function() {
    return $timeout(function() {
      $scope.Wings =  $scope.Wings  || [
        { id: 1, name: 'A Wing' },
        { id: 2, name: 'B Wing' }
      ];
    }, 350);
  };

    // $scope.tView = {};
    // $scope.tView.Tower = "All";
    // $scope.tView.Floor = "All";
    // $scope.tView.Wing = "All";
    $scope.TowersTicket = [
      { id: 1, name: 'All' },
      { id: 2, name: 'Tower A' },
      { id: 3, name: 'Tower B' }
    ];
    $scope.FloorsTicket = [
      { id: 1, name: 'All' },
      { id: 2, name: 'Ground Floor' },
      { id: 3, name: '1st Floor' },
      { id: 4, name: '2nd Floor' }
    ];
    $scope.WingsTicket =  [
      { id: 1, name: 'All' },
      { id: 2, name: 'A Wing' },
      { id: 3, name: 'B Wing' }
    ];
  $scope.fetchBookings = function(bookingType,Area,tower,floor_seater){
    $scope.showChartDiv = true;
    var date = new Date();
    var currHour = date.getHours();
    var currentMinute = date.getMinutes();
    // var currHour =13;
    // var currentMinute = 00;

    var todayDate = date.getDate();
    if(todayDate <10){   todayDate = "0"+todayDate;  }

    var mon = date.getMonth()+1;
    var year = date.getFullYear();
    if(mon<10){   mon = "0"+mon;  }

    var currDate = year+"-"+mon+"-"+todayDate;
    $scope.JsonDataDesk = [['Floor','Seats',{role:'style'}],
    ['Sales',0,'color:#002e6d'],
    ['HR',0,'color:#002e6d'],
    ['Finance',0,'color:#002e6d'],
    ['Operations',0,'color:#002e6d'],
    ['Delivery',0,'color:#002e6d'],
  ];
  $scope.JsonDataRoom = [['Zones','Seats',{role:'style'}],
  ['Ground Floor',0,'color:#002e6d'],
  ['1st Floor',0,'color:#002e6d'],
  ['2nd Floor',0,'color:#002e6d']
];

mainService.getAllTheBookingsSB().success(function(response){
  $scope.showChartDiv = true;
  for(var i=0;i<response.length;i++){
    var responseStartTime = response[i].StartTime.split(":");
    var responseStartTimeHour = parseInt(responseStartTime[0]);
    var responseStartTimeMinute = parseInt(responseStartTime[1]);
    var responseEndTime = response[i].EndTime.split(":");
    var responseEndTimeHour = responseEndTime[0];
    var responseEndTimeMinute = responseEndTime[1];

    if(response[i].Area == Area && response[i].Tower == tower.name &&  response[i].BookingDate == currDate ){
      if(
        (  (  ( currHour == responseStartTimeHour && currentMinute >= responseStartTimeMinute) ||(currHour > responseStartTimeHour)  ) &&  (  ( currHour == responseEndTimeHour && currentMinute < responseEndTimeMinute) ||(currHour < responseEndTimeHour)  ) ) ||
        (  (  (  currHour == responseStartTimeHour && currentMinute < responseStartTimeMinute) || currHour < responseStartTimeHour )  &&    (  (currHour == responseEndTimeHour && currentMinute > responseEndTimeMinute) || currHour > responseEndTimeHour )  ) ){
          if(response[i].BookingType == 'Room Booking' && response[i].TypeOfSeater == floor_seater ){
            for(var j=1;j<$scope.JsonDataRoom.length-1;j++){
              if($scope.JsonDataRoom[j][0] == response[i].Floor ){
                $scope.JsonDataRoom[j][1] = $scope.JsonDataRoom[j][1]+1;
              }
            }
          }
          else if(response[i].BookingType == 'Desk Booking'  && response[i].Floor == floor_seater ){
            for(var k=1;k<$scope.JsonDataDesk.length;k++){
              if($scope.JsonDataDesk[k][0] == response[i].Zone ){
                $scope.JsonDataDesk[k][1] = $scope.JsonDataDesk[k][1]+1;
              }
            }
          }
        }
      }
    }

    /*Bar Graph code starts*/

    var deskBookingData = $scope.JsonDataDesk;
    var roomBookingData = $scope.JsonDataRoom;
    google.charts.load('current', {packages: ['corechart', 'bar']});
    if(bookingType == "Desk Booking"){
      google.charts.setOnLoadCallback(drawBasic);
      function drawBasic() {
        var data = google.visualization.arrayToDataTable(deskBookingData);

        var options = {
          hAxis: {
            title: 'Zones',
            titleTextStyle: {
              fontSize: 12,
              bold: true
            }
          },
          vAxis: {
            gridlines: {
              count: 5
            },
            title: 'Occupied Seats',
            titleTextStyle: {
              fontSize: 12,
              bold: true
            },
            ticks: [0, 1, 2, 3, 4, 5]
          },
          legend: { position: "none" }
        };
        var chart = new google.visualization.ColumnChart(
          document.getElementById("chart_divDesk"+Area));

          chart.draw(data,options);
        }
      }
      else{
        // google.charts.load('current', {packages: ['corechart', 'bar']});
        google.charts.setOnLoadCallback(drawBasic);
        function drawBasic() {
          var data = google.visualization.arrayToDataTable(roomBookingData);
          var options = {
            hAxis: {
              title: 'Floors',
              titleTextStyle: {
                fontSize: 12,
                bold: true
              }
            },
            vAxis: {
              title: 'Occupied Rooms',
              ticks: [0, 1, 2, 3],
              titleTextStyle: {
                fontSize: 12,
                bold: true
              }
            },
            legend: { position: "none" }
          };
          var chart = new google.visualization.ColumnChart(
            document.getElementById("chart_divRoom"+Area));

            chart.draw(data,options);
          }
        }
        // $scope.disableSABtn = true;

        /*Bar Graph code ends*/
      })
    }
    $scope.ShowCards = function(bookingType){
      if(bookingType == "Desk Booking"){
        $scope.dbkgShow = true;
        $scope.rbkgShow = false;
        $scope.btnOpacityRB = ".2";
        $scope.btnOpacityDB = "1";

      }else{
        $scope.dbkgShow = false;
        $scope.rbkgShow = true;
        $scope.btnOpacityDB = ".2";
        $scope.btnOpacityRB = "1";
      }
    }
    $scope.hideChartDiv = function(){
      $scope.showChartDiv = false;
    }

    $scope.ShowAnalyticsDaily = function(bookingType,timeType){
      $scope.showChartDiv = true;
      var date = new Date();
      var currHour = date.getHours();
      var currentMinute = date.getMinutes();
      var todayDate = date.getDate();

      if(todayDate <10){   todayDate = "0"+todayDate;  }

      var mon = date.getMonth()+1;
      var year = date.getFullYear();

      if(mon<10){   mon = "0"+mon;  }

      var currDate = year+"-"+mon+"-"+todayDate;
      var filtObj = {};
      filtObj.date = currDate;
      filtObj.bookingType = bookingType;

      mainService.getTodayBookingsSB(filtObj).success(function(response){
        //-------------variables used for daily graph-------------------
        var startTimeH = 8;
        var startTimeM = "00";
        var maxSeat = [];
        var maxSeatMonth = [];
        var maxSeatWeek = [];
        var maxSeatRoom = [];
        var maxSeatMonthRoom = [];
        var maxSeatWeekRoom = [];
        var dailyBasisJsonData = [['Time','Fareham Seats','Swindon Seats','Cheltenham Seats']];
        var dailyBasisJsonDataRoom = [['Time','Fareham Rooms','Swindon Rooms','Cheltenham Rooms']];
        var  time  ="8:00";
        // var JsonDaily = [['Time','Fareham Seats','Swindon Seats','Cheltenham Seats']];

        //-----------------while loop logic for counting the booked seats on current date-------------------
        while(time != "23:30" ){
          var timeBooking = {};
          var timeObject = {};
          var arrayInTimeObj = [];
          var FarehamCount = 0;
          var SwindonCount = 0;
          var CheltenhamCount = 0;
          var FarehamCountRoom = 0;
          var SwindonCountRoom = 0;
          var CheltenhamCountRoom = 0;
          var singleLine = [];
          timeBooking['time'] = time;
          timeBooking['seats'] = 0;
          for (var i = 0; i <response.length; i++) {
            var responseStartTime = response[i].StartTime.split(":");
            var responseStartTimeHour = parseInt(responseStartTime[0]);
            var responseStartTimeMinute = parseInt(responseStartTime[1]);
            var responseEndTime = response[i].EndTime.split(":");
            var responseEndTimeHour = responseEndTime[0];
            var responseEndTimeMinute = responseEndTime[1];
            time = startTimeH+":"+startTimeM;
            if
            (  (  ( startTimeH == responseStartTimeHour && startTimeM >= responseStartTimeMinute) ||(startTimeH > responseStartTimeHour)  ) &&
            (  ( startTimeH == responseEndTimeHour && startTimeM < responseEndTimeMinute) ||(startTimeH < responseEndTimeHour)  ) )  {
              if(response[i].Area == 'Fareham'){
                FarehamCount = FarehamCount+1;
              }
              if(response[i].Area == 'Swindon'){
                SwindonCount += 1;
              }
              if(response[i].Area == 'Cheltenham'){
                CheltenhamCount += 1;
              }

            }
          }
          //------------- code for getting json format in  [{v: [8, 0, 0], f: '8 am'}, 1, 0, 0] -------------
          arrayInTimeObj[0] = startTimeH; arrayInTimeObj[1] = startTimeM.charAt(0); arrayInTimeObj[2] = startTimeM.charAt(1);
          var objj= {};
          objj.v = arrayInTimeObj;
          objj.f = time;
          singleLine = [];
          singleLine.push(objj); singleLine.push(FarehamCount); singleLine.push(SwindonCount); singleLine.push(CheltenhamCount);
          maxSeat.push(FarehamCount);
          maxSeat.push(SwindonCount);
          maxSeat.push(CheltenhamCount);
          dailyBasisJsonData.push(singleLine);
          if(startTimeM == "00"){
            startTimeM = "30";
            startTimeH = startTimeH;
          }else if(startTimeM == "30"){
            startTimeM = "00";
            startTimeH = startTimeH+1;
          }
          time = startTimeH+":"+startTimeM;
        }
        //---------------end Of while loop logic for finding daily bookings----------------------

        google.charts.load('current', {packages: ['corechart', 'line']});
        google.charts.setOnLoadCallback(drawBasic);

        function drawBasic() {
          var data = new google.visualization.arrayToDataTable(dailyBasisJsonData);
          var ticksArray = [];
          var len = Math.max.apply(null,maxSeat);
          // for(var i=0;i<=len+1;i++){
          //   ticksArray.push(i);
          // }
          if(len <= 10){
            ticksArray = [0,1,2,3,4,5];
          }else if(len <= 20){
            ticksArray = [0,4,8,12,16,20];
          }else if(len <= 30){
            ticksArray = [0,6,12,18,24,30];
          }else if(len <= 40){
            ticksArray = [0,8,16,24,32,40];
          }else if(len <= 50){
            ticksArray = [0,10,20,30,40,50];
          }else if(len <= 60){
            ticksArray = [0,12,24,36,48,60];
          }else if(len <= 70){
            ticksArray = [0,14,28,42,56,70];
          }else if(len <= 80){
            ticksArray = [0,16,32,48,64,80];
          }else if(len <= 90){
            ticksArray = [0,18,36,54,72,90];
          }else if(len <= 100){
            ticksArray = [0,20,40,60,80,100];
          }else if(len <= 110){
            ticksArray = [0,22,44,66,88,110];
          }else if(len <= 120){
            ticksArray = [0,24,48,72,96,120];
          }
          else if(len <= 130){
            ticksArray = [0,26,52,78,104,130];
          }else{
            ticksArray = [0,40,80,120,160,200];
          }
          if($scope.includeMobileTemplate){
            var options = {
              hAxis: {
                title: 'Time of Day',
                titleTextStyle: {
                  fontSize: 12,
                  bold: true
                },
                format: 'H ',
                ticks: [[8, 00, 0],[9, 00, 0],[10, 00, 0],[11, 00, 0],[12, 00, 0],[13, 00, 0],[14, 00, 0],[15, 00, 0],[16, 00, 0],[17, 00, 0],[18, 00, 0],[19, 00, 0],[20, 00, 0],[21, 00, 0],[20, 00, 0],[21, 00, 0],[22, 00, 0],[23, 00, 0]],
                ticksTextStyle:{
                  fontSize: 5
                }
              },
              vAxis: {
                title: 'Occupied Seats',
                titleTextStyle: {
                  fontSize: 12,
                  bold: true
                },
                ticks: ticksArray
              },
              colors: ['#a52714', '#097138','#002e6d'],
              legend: { position: "top",maxLines: 3}
            };
          }else{
            var options = {
              width: 730,
              height: 350,
              hAxis: {
                title: 'Time of Day',
                titleTextStyle: {
                  fontSize: 12,
                  bold: true
                },
                format: 'H',
                ticks: [[8, 00, 0],[9, 00, 0],[10, 00, 0],[11, 00, 0],[12, 00, 0],[13, 00, 0],[14, 00, 0],[15, 00, 0],[16, 00, 0],[17, 00, 0],[18, 00, 0],[19, 00, 0],[20, 00, 0],[21, 00, 0],[20, 00, 0],[21, 00, 0],[22, 00, 0],[23, 00, 0]],
                ticksTextStyle:{
                  fontSize: 5
                }
              },
              vAxis: {
                title: 'Occupied Seats',
                titleTextStyle: {
                  fontSize: 12,
                  bold: true
                },
                ticks: ticksArray
              },
              colors: ['#a52714', '#097138','#002e6d'],
              legend: { position: "top"}
            };
          }
          if(bookingType == "Desk Booking"){
            var chart = new google.visualization.LineChart(
              document.getElementById('ShowAnalyticsGraphDesk'));
            }else{
              var chart = new google.visualization.LineChart(
                document.getElementById('ShowAnalyticsGraphRoom'));
              }
              chart.draw(data, options);
            }
          })

        }

        $scope.ShowAnalyticsweekly = function(bookingType,timeType){

          $scope.showChartDiv = true;
          var date = new Date();
          var currHour = date.getHours();
          var currentMinute = date.getMinutes();
          var todayDate = date.getDate();
          if(todayDate <10){   todayDate = "0"+todayDate;  }
          var mon = date.getMonth()+1;
          var year = date.getFullYear();
          if(mon<10){   mon = "0"+mon;  }

          var currDate = year+"-"+mon+"-"+todayDate;
          // need to think for the logic of fetching only this week bookings and booking type //as of now passing only booking type for filteration//
          mainService.getWeekBookingsSB(bookingType).success(function(response){
            var maxSeatWeek = [];
            var maxSeatWeekRoom = [];
            var week = date.getDay();
            var firstDayOfWeek = parseInt(todayDate) - week+1;
            // var lastDayOfWeek =  parseInt(todayDate) - week+1;
            var firstDayDate = year+"-"+mon+"-"+firstDayOfWeek;
            var loopWhile = 0;
            var weekArray = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
            // var weekArray = [1,2,3,4,5,6,7];
            var weekBasisJsonData = [['Week','Fareham Seats','Swindon Seats','Cheltenham Seats']];
            var weekBasisJsonDataRoom = [['Week','Fareham Rooms','Swindon Rooms','Cheltenham Rooms']];
            var singleLineArry = [];
            while(loopWhile != 7){
              var FweekCount = 0;
              var SweekCount = 0;
              var CweekCount = 0;
              for (var i = 0; i < response.length; i++) {
                if(response[i].BookingDate == firstDayDate){
                  if(response[i].Area == 'Fareham'){
                    FweekCount += 1;
                  }
                  if(response[i].Area == 'Swindon'){
                    SweekCount += 1;
                  }
                  if(response[i].Area == 'Cheltenham'){
                    CweekCount += 1;
                  }
                }
              }
              //------------------For Desk booking json data-------------------
              singleLineArry = [];
              singleLineArry[0] = weekArray[loopWhile]; singleLineArry[1] = FweekCount; singleLineArry[2] = SweekCount; singleLineArry[3] = CweekCount;
              weekBasisJsonData.push(singleLineArry);
              maxSeatWeek.push(FweekCount);
              maxSeatWeek.push(SweekCount);
              maxSeatWeek.push(CweekCount);
              //--------end of room booking json data--------------------
              loopWhile++;
              firstDayOfWeek++;
              if(firstDayOfWeek <10){
                firstDayOfWeek = "0"+firstDayOfWeek;
              }
              firstDayDate =year+"-"+mon+"-"+firstDayOfWeek;
            }
            // console.log(weekBasisJsonData);
            google.charts.load('current', {packages: ['corechart', 'line']});
            google.charts.setOnLoadCallback(drawBasic);

            function drawBasic() {
              var data = new google.visualization.arrayToDataTable(weekBasisJsonData);
              var ticksArray = [];
              var len = Math.max.apply(null,maxSeatWeek);
              if(len <= 10){
                ticksArray = [0,1,2,3,4,5];
              }else if(len <= 20){
                ticksArray = [0,4,8,12,16,20];
              }else if(len <= 30){
                ticksArray = [0,6,12,18,24,30];
              }else if(len <= 40){
                ticksArray = [0,8,16,24,32,40];
              }else if(len <= 50){
                ticksArray = [0,10,20,30,40,50];
              }else if(len <= 60){
                ticksArray = [0,12,24,36,48,60];
              }else if(len <= 70){
                ticksArray = [0,14,28,42,56,70];
              }else if(len <= 80){
                ticksArray = [0,16,32,48,64,80];
              }else if(len <= 90){
                ticksArray = [0,18,36,54,72,90];
              }else if(len <= 100){
                ticksArray = [0,20,40,60,80,100];
              }else if(len <= 110){
                ticksArray = [0,22,44,66,88,110];
              }else if(len <= 120){
                ticksArray = [0,24,48,72,96,120];
              }
              else if(len <= 130){
                ticksArray = [0,26,52,78,104,130];
              }else{
                ticksArray = [0,40,80,120,160,200];
              }
              console.log(data);
                var options = {
                  width: 730,
                  height: 350,
                  hAxis: {
                    title: 'Days',
                    titleTextStyle: {
                      fontSize: 12,
                      bold: true
                    }
                  },
                  vAxis: {
                    title: 'Occupied Seats',
                    titleTextStyle: {
                      fontSize: 12,
                      bold: true
                    },
                    ticks: ticksArray
                  },
                  colors: ['#a52714', '#097138','#002e6d'],
                  legend: { position: "top" }
                };


              if(bookingType == "Desk Booking"){
                var chart = new google.visualization.LineChart(
                  document.getElementById('ShowAnalyticsGraphDesk'));
                }else{
                  var chart = new google.visualization.LineChart(
                    document.getElementById('ShowAnalyticsGraphRoom'));
                  }
                  chart.draw(data, options);
                }
              })
            }

            $scope.ShowAnalyticsMonthly = function(bookingType,timeType){
              $scope.showChartDiv = true;
              var date = new Date();
              var currHour = date.getHours();
              var currentMinute = date.getMinutes();
              var todayDate = date.getDate();
              if(todayDate <10){   todayDate = "0"+todayDate;  }
              var mon = date.getMonth()+1;
              var year = date.getFullYear();
              if(mon<10){   mon = "0"+mon;  }
              var maxSeatMonth = [];
              var maxSeatMonthRoom = [];
              var currDate = year+"-"+mon+"-"+todayDate;
              var firstDayMonth = (new Date(date.getFullYear(), date.getMonth(), 1)).getDate();
              var lastDayMonth  = (new Date(date.getFullYear(), date.getMonth() + 1, 0)).getDate();

              mainService.getMonthBookingsSB(bookingType).success(function(response){
                var inr = 1;
                var MonthBasisJsonData = [['Date','Fareham Seats','Swindon Seats','Cheltenham Seats']];
                var MonthBasisJsonDataRoom = [['Date','Fareham Rooms','Swindon Rooms','Cheltenham Rooms']];
                while(inr != lastDayMonth){
                  var FmonthCount = 0;
                  var SmonthCount = 0;
                  var CmonthCount = 0;
                  var FmonthCountRoom = 0;
                  var SmonthCountRoom = 0;
                  var CmonthCountRoom = 0;
                  for (var i = 0; i < response.length; i++) {
                    var resMonth = parseInt(response[i].BookingDate.substring(5,7));
                    if(resMonth ==  date.getMonth()+1){
                      if(parseInt(response[i].BookingDate.substring(8,10)) == inr ){
                        if(response[i].Area == 'Fareham'){
                          FmonthCount += 1;
                        }
                        if(response[i].Area == 'Swindon'){
                          SmonthCount += 1;
                        }
                        if(response[i].Area == 'Cheltenham'){
                          CmonthCount += 1;
                        }
                      }
                    }
                  }
                  var s = [];
                  s[0] = inr; s[1] = FmonthCount; s[2] = SmonthCount; s[3] = CmonthCount;
                  MonthBasisJsonData.push(s);
                  maxSeatMonth.push(FmonthCount); maxSeatMonth.push(SmonthCount); maxSeatMonth.push(CmonthCount);
                inr++;
                }

                google.charts.load('current', {packages: ['corechart', 'line']});
                google.charts.setOnLoadCallback(drawBasic);

                function drawBasic() {
                  // if(bookingType == "Desk Booking"){
                  var data = new google.visualization.arrayToDataTable(MonthBasisJsonData);
                  var ticksArray = [];
                  var len = Math.max.apply(null,maxSeatMonth);
                  // for(var i=0;i<=len+1;i++){
                  //   ticksArray.push(i);
                  // }
                  if(len <= 10){
                    ticksArray = [0,1,2,3,4,5];
                  }else if(len <= 20){
                    ticksArray = [0,4,8,12,16,20];
                  }else if(len <= 30){
                    ticksArray = [0,6,12,18,24,30];
                  }else if(len <= 40){
                    ticksArray = [0,8,16,24,32,40];
                  }else if(len <= 50){
                    ticksArray = [0,10,20,30,40,50];
                  }else if(len <= 60){
                    ticksArray = [0,12,24,36,48,60];
                  }else if(len <= 70){
                    ticksArray = [0,14,28,42,56,70];
                  }else if(len <= 80){
                    ticksArray = [0,16,32,48,64,80];
                  }else if(len <= 90){
                    ticksArray = [0,18,36,54,72,90];
                  }else if(len <= 100){
                    ticksArray = [0,20,40,60,80,100];
                  }else if(len <= 110){
                    ticksArray = [0,22,44,66,88,110];
                  }else if(len <= 120){
                    ticksArray = [0,24,48,72,96,120];
                  }
                  else if(len <= 130){
                    ticksArray = [0,26,52,78,104,130];
                  }else{
                    ticksArray = [0,40,80,120,160,200];
                  }
                  if($scope.includeMobileTemplate){
                    var options = {
                      hAxis: {
                        title: 'Days',
                        titleTextStyle: {
                          fontSize: 12,
                          bold: true
                        }
                      },
                      vAxis: {
                        title: 'Occupied Seats',
                        titleTextStyle: {
                          fontSize: 12,
                          bold: true
                        },
                        ticks: ticksArray
                      },
                      colors: ['#a52714', '#097138','#002e6d'],
                      legend: { position: "top",maxLines: 3 }
                    };
                  }else{
                    var options = {
                      width: 730,
                      height: 350,
                      hAxis: {
                        title: 'Days',
                        titleTextStyle: {
                          fontSize: 12,
                          bold: true
                        }
                      },
                      vAxis: {
                        title: 'Occupied Seats',
                        titleTextStyle: {
                          fontSize: 12,
                          bold: true
                        },
                        ticks: ticksArray
                      },
                      colors: ['#a52714', '#097138','#002e6d'],
                      legend: { position: "top" }
                    };
                  }
                  // }
                  if(bookingType == "Desk Booking"){
                    var chart = new google.visualization.LineChart(
                      document.getElementById('ShowAnalyticsGraphDesk'));
                    }else{
                      var chart = new google.visualization.LineChart(
                        document.getElementById('ShowAnalyticsGraphRoom'));
                      }
                      chart.draw(data, options);
                    }
                  })
                }
                $scope.selected = [1];
                $scope.toggle = function (Area, list) {
                  var idx = list.indexOf(Area);

                if (idx > -1) {
                    list.splice(idx, 1);
                  }
                  else {
                    list.push(Area);
                  }

               };

              $scope.exists = function (Area, list) {
                  return list.indexOf(Area) > -1;
                };
                // $scope.exists = function (Area, type) {
                //   console.log("Area"+Area+"type"+type);
                // };
                $scope.selectedAreaIs = "Fareham";
                $scope.FilterObject = {};
                $scope.selectedArea = function(area){
                  $scope.selectedAreaIs = area;
                }
                $scope.viewTickets = function(searchObject){
                  if(searchObject.Tower.name != "All"){
                      $scope.FilterObject.Tower = searchObject.Tower.name;
                  }
                  if(searchObject.Floor.name != "All"){
                      $scope.FilterObject.Floor = searchObject.Floor.name;
                  }
                  if(searchObject.Wing.name != "All"){
                      $scope.FilterObject.Wing = searchObject.Wing.name;
                  }
                  $scope.FilterObject.bookingType = $scope.ticketViewBookingType ;
                  $scope.FilterObject.Area = $scope.selectedAreaIs.name;
                  mainService.findTicketsWithFilterSB($scope.FilterObject).success(function(response){
                    $scope.FilteredTickets = response;
                    $scope.ticketLen = $scope.FilteredTickets.length;
                  })
                }
              })
