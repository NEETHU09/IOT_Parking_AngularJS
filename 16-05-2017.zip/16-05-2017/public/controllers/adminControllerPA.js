angular.module('appRoute')
.controller('adminControllerPA',function($window,$scope,$timeout,mainService,$q,$state,$stateParams,$mdDialog,authService){
  // $scope.User = localStorage.getItem("token");
  $scope.logValBD = $stateParams.param1;
  $scope.logValLO = $stateParams.param2;
    $scope.logValPA = $stateParams.param3;
  $scope.ShowBookSeat = $stateParams.showSeat;
  $scope.HideBookSeat = $stateParams.HideBookSeat;
  $scope.showChartDiv = true;
  // $scope.disableSABtn = false;
  $scope.dbkgShow = true;
  $scope.rbkgShow = false;
  $scope.btnOpacityDB = "1";
  $scope.btnOpacityRB = ".2";
  $scope.tBar = "always";
  $scope.includeDesktopTemplate = false;
  $scope.includeMobileTemplate = false;

  $scope.slotimg="../images/blue.png";

  var screenWidth = $window.innerWidth;

  if (screenWidth < 768){
    $scope.includeMobileTemplate = true;
    $scope.tBar = "auto";
  }else{
    $scope.includeDesktopTemplate = true;
    $scope.tBar = "always";
  }
  console.log("Screen Mobile Size:"+$scope.includeMobileTemplate);
  console.log("Screen Desktop Size:"+$scope.includeDesktopTemplate);
  var userObj = authService.getUser();
  if(userObj != undefined){
    var userName = userObj.userName;
    $scope.currentUser = userName.substring(0,1).toUpperCase()+userName.substring(1,userName.length);
    console.log("current user is" +$scope.currentUser);
    $scope.User = userObj.eMail;
  }
  mainService.getAllTheBookingsPA().success(function(data){
    for (var i = 0; i < data.length; i++) {
      $scope.AllbookingDetails.push(data[i]);
    }
    var len = $scope.AllbookingDetails.length;
    console.log(len);
  })


  $scope.AllbookingDetails = [];
  $scope.Tower = null;
  $scope.Towers = null;
  $scope.Areas =[
    { id: 1, name: 'Fareham' },
    { id: 2, name: 'Swindon' },
    { id: 3, name: 'Cheltenham' }
  ];
  $scope.loadFloors = function() {
    return $timeout(function() {
      $scope.Floors =  $scope.Floors  || [
        { id: 1, name: 'Ground Floor' },
        { id: 2, name: '1st Floor' },
        { id: 3, name: '2nd Floor' },
        { id: 4, name: '3rd Floor' },

      ];
    }, 350);
  };
  var loc = "";
  $scope.fetchBookings = function(location){
      loc = location;
      console.log("Assigning location : "+loc);
      $scope.showChartDiv = true;
      console.log(location);
      var date = new Date();
      var currHour = date.getHours();
      var currentMinute = date.getMinutes();

      var todayDate = date.getDate();
      if(todayDate <10){   todayDate = "0"+todayDate;  }

      var mon = date.getMonth()+1;
      var year = date.getFullYear();
      if(mon<10){   mon = "0"+mon;  }

      var currDate = year+"-"+mon+"-"+todayDate;
      $scope.JsonDataDesk = [['Parking Location', 'Available Slots', 'Occupied Slots', 'Booked Slots'],
          ['Ground Floor', 100, 0, 0],
          ['1st Floor', 100, 0, 0],
          ['2nd Floor', 100, 0, 0],
          ['3rd Floor', 100, 0, 0]
    ];

    mainService.getLocationBookingPA(location,currDate).success(function(response){
        for (var i = 0; i < response.length; i++) {
          var responseStartTime = response[i].StartTime.split(":");
             var responseStartTimeHour = parseInt(responseStartTime[0]);
             var responseStartTimeMinute = parseInt(responseStartTime[1]);
             var responseEndTime = response[i].EndTime.split(":");
             var responseEndTimeHour = responseEndTime[0];
             var responseEndTimeMinute = responseEndTime[1];
             if(
                   (  (  ( currHour == responseStartTimeHour && currentMinute >= responseStartTimeMinute) ||(currHour > responseStartTimeHour)  ) &&  (  ( currHour == responseEndTimeHour && currentMinute < responseEndTimeMinute) ||(currHour < responseEndTimeHour)  ) ) ||
                   (  (  (  currHour == responseStartTimeHour && currentMinute < responseStartTimeMinute) || currHour < responseStartTimeHour )  &&    (  (currHour == responseEndTimeHour && currentMinute > responseEndTimeMinute) || currHour > responseEndTimeHour )  ) ){

                          //  $scope.JsonDataDesk[1][1] = $scope.JsonDataDesk[1][1]+1;
                          for (var j = 1; j < $scope.JsonDataDesk.length; j++) {
                            if($scope.JsonDataDesk[j][0] == response[i].Floor){
                              $scope.JsonDataDesk[j][3] = $scope.JsonDataDesk[j][3]+1;
                              $scope.JsonDataDesk[j][1] = $scope.JsonDataDesk[j][1]-1;
                              console.log("incrementing the booked seats : "+$scope.JsonDataDesk[j][3]);
                              console.log("decrementing the vailable  seats : "+$scope.JsonDataDesk[j][1]);
                            }
                          }
                   }
        }
          console.log($scope.JsonDataDesk);
          var parkingData = $scope.JsonDataDesk;
          google.charts.load('current', {packages: ['corechart', 'bar']});
    google.charts.setOnLoadCallback(drawBasic);
     function drawBasic() {
       var data = google.visualization.arrayToDataTable(parkingData);

       var options = {
         width:800,
         height:360,
         hAxis: {
           title: 'Parking Locations',
           titleTextStyle: {
             fontSize: 12,
             bold: true
           }
         },
         vAxis: {
           gridlines: {
             count: 5
           },
           title: 'Parking Slots',
           titleTextStyle: {
             fontSize: 12,
             bold: true
           },
           ticks: [0, 10, 20, 30, 40, 50,60,70,80,90,100]
         },
         legend: { position: "top" }
       };
          if(loc == "Electronic City"){
            var chart = new google.visualization.ColumnChart(document.getElementById("chartEC"));
            chart.draw(data, options);
          }else if(loc == "Sarjapur"){
            var chart = new google.visualization.ColumnChart(document.getElementById("chartSJP"));
            chart.draw(data, options);
          }else if(loc == "Koramangala"){
            var chart = new google.visualization.ColumnChart(document.getElementById("chartKMGL"));
            chart.draw(data, options);
          }else if(loc == "Whitefield"){
            var chart = new google.visualization.ColumnChart(document.getElementById("chartWTFD"));
            chart.draw(data, options);
          }else{
            var chart = new google.visualization.ColumnChart(document.getElementById("chartEC"));
            chart.draw(data, options);
          }

        }
   })
  }
  $scope.slotNames = {rows:['A','B','C','D','E','F','G','H','I','J']};
  var place = "";
  var floorPA = "";
  $scope.FloorBookings = [];
    $scope.bookedSeats = [];
    $scope.fetchBookedParkingSlots = function(location,floor){
      place = location;
      floorPA = floor;
      console.log("Assigning location and Floor : "+place+""+floorPA);
      var date = new Date();
      var currHour = date.getHours();
      var currentMinute = date.getMinutes();

      var todayDate = date.getDate();
      if(todayDate <10){   todayDate = "0"+todayDate;  }

      var mon = date.getMonth()+1;
      var year = date.getFullYear();
      if(mon<10){   mon = "0"+mon;  }

      var currDate = year+"-"+mon+"-"+todayDate;
          mainService.getLocationFloorBookingPA(location,floor,currDate).success(function(response){
            for (var i = 0; i < response.length; i++) {
              var responseStartTime = response[i].StartTime.split(":");
                 var responseStartTimeHour = parseInt(responseStartTime[0]);
                 var responseStartTimeMinute = parseInt(responseStartTime[1]);
                 var responseEndTime = response[i].EndTime.split(":");
                 var responseEndTimeHour = responseEndTime[0];
                 var responseEndTimeMinute = responseEndTime[1];
                 if(
                       (  (  ( currHour == responseStartTimeHour && currentMinute >= responseStartTimeMinute) ||(currHour > responseStartTimeHour)  ) &&  (  ( currHour == responseEndTimeHour && currentMinute < responseEndTimeMinute) ||(currHour < responseEndTimeHour)  ) ) ||
                       (  (  (  currHour == responseStartTimeHour && currentMinute < responseStartTimeMinute) || currHour < responseStartTimeHour )  &&    (  (currHour == responseEndTimeHour && currentMinute > responseEndTimeMinute) || currHour > responseEndTimeHour )  ) ){

                              $scope.FloorBookings.push(response[i]);
                              $scope.bookedSeats.push(response[i].SeatNumber);
                       }
            }
            console.log("NOT SORTED");
            console.log($scope.bookedSeats);
            // $scope.bookedSeats = $scope.bookedSeats.sort();
            console.log("SORTED");
            console.log($scope.bookedSeats);
            var slotsArrayG = ["GA01","GA02","GA03","GA04","GA05","GA06","GA07","GA08","GA09","GA10",
                              "GB01","GB02","GB03","GB04","GB05","GB06","GB07","GB08","GB09","GB10",
                              "GC01","GC02","GC03","GC04","GC05","GC06","GC07","GC08","GC09","GC10",
                              "GD01","GD02","GD03","GD04","GD05","GD06","GD07","GD08","GD09","GD10",
                              "GE01","GE02","GE03","GE04","GE05","GE06","GE07","GE08","GE09","GE10",
                              "GF01","GF02","GF03","GF04","GF05","GF06","GF07","GF08","GF09","GF10",
                              "GG01","GG02","GG03","GG04","GG05","GG06","GG07","GG08","GG09","GG10",
                              "GH01","GH02","GH03","GH04","GH05","GH06","GH07","GH08","GH09","GH10",
                              "GI01","GI02","GI03","GI04","GI05","GI06","GI07","GI08","GI09","GI10",
                              "GJ01","GJ02","GJ03","GJ04","GJ05","GJ06","GJ07","GJ08","GJ09","GJ10"
          ];
          var slotsArrayF = ["1A01","1A02","1A03","1A04","1A05","1A06","1A07","1A08","1A09","1A10",
                            "1B01","1B02","1B03","1B04","1B05","1B06","1B07","1B08","1B09","1B10",
                            "1C01","1C02","1C03","1C04","1C05","1C06","1C07","1C08","1C09","1C10",
                            "1D01","1D02","1D03","1D04","1D05","1D06","1D07","1D08","1D09","1D10",
                            "1E01","1E02","1E03","1E04","1E05","1E06","1E07","1E08","1E09","1E10",
                            "1F01","1F02","1F03","1F04","1F05","1F06","1F07","1F08","1F09","1F10",
                            "1G01","1G02","1G03","1G04","1G05","1G06","1G07","1G08","1G09","1G10",
                            "1H01","1H02","1H03","1H04","1H05","1H06","1H07","1H08","1H09","1H10",
                            "1I01","1I02","1I03","1I04","1I05","1I06","1I07","1I08","1I09","1I10",
                            "1J01","1J02","1J03","1J04","1J05","1J06","1J07","1J08","1J09","1J10"
        ];
        var slotsArrayS = ["2A01","2A02","2A03","2A04","2A05","2A06","2A07","2A08","2A09","2A10",
                          "2B01","2B02","2B03","2B04","2B05","2B06","2B07","2B08","2B09","2B10",
                          "2C01","2C02","2C03","2C04","2C05","2C06","2C07","2C08","2C09","2C10",
                          "2D01","2D02","2D03","2D04","2D05","2D06","2D07","2D08","2D09","2D10",
                          "2E01","2E02","2E03","2E04","2E05","2E06","2E07","2E08","2E09","2E10",
                          "2F01","2F02","2F03","2F04","2F05","2F06","2F07","2F08","2F09","2F10",
                          "2G01","2G02","2G03","2G04","2G05","2G06","2G07","2G08","2G09","2G10",
                          "2I01","2I02","2I03","2I04","2I05","2I06","2I07","2I08","2I09","2I10",
                          "2H01","2H02","2H03","2H04","2H05","2H06","2H07","2H08","2H09","2H10",
                          "2J01","2J02","2J03","2J04","2J05","2J06","2J07","2J08","2J09","2J10"
        ];
        var slotsArrayT = ["3A01","3A02","3A03","3A04","3A05","3A06","3A07","3A08","3A09","3A10",
                          "3B01","3B02","3B03","3B04","3B05","3B06","3B07","3B08","3B09","3B10",
                          "3C01","3C02","3C03","3C04","3C05","3C06","3C07","3C08","3C09","3C10",
                          "3D01","3D02","3D03","3D04","3D05","3D06","3D07","3D08","3D09","3D10",
                          "3E01","3E02","3E03","3E04","3E05","3E06","3E07","3E08","3E09","3E10",
                          "3F01","3F02","3F03","3F04","3F05","3F06","3F07","3F08","3F09","3F10",
                          "3G01","3G02","3G03","3G04","3G05","3G06","3G07","3G08","3G09","3G10",
                          "3I01","3I02","3I03","3I04","3I05","3I06","3I07","3I08","3I09","3G10",
                          "3H01","3H02","3H03","3H04","3H05","3H06","3H07","3H08","3H09","3H10",
                          "3J01","3J02","3J03","3J04","3J05","3J06","3J07","3J08","3J09","3J10"
        ];

            var bSlots = $scope.bookedSeats;
            slotsArray = [];
            if(floor == 'Ground Floor'){
              slotsArray = slotsArrayG;
              $scope.floorName = 'G';
              // var rows = $scope.slotNames.rows;
              // var sNames = [];
              //   for(var i=0;i<rows.length;i++){
              //     for(var k=1;k<=10;k++){
              //       var fName = "";
              //       if(k == 10){
              //         fName = "1"+rows[i]+k;
              //       }else{
              //         fName = "1"+rows[i]+"0"+k;
              //       }
              //       sNames.push(fName);
              //     }
              //   }
              //   $scope.slotNames = sNames;
            }
            else if(floor == '1st Floor'){
              slotsArray = slotsArrayF;
              $scope.floorName = '1';
            }
            else if(floor == '2nd Floor'){
              slotsArray = slotsArrayS;
              $scope.floorName = '2';
            }
            else if(floor == '3rd Floor'){
              slotsArray = slotsArrayT;
              $scope.floorName = '3';
            }

            for (var i = 0; i < slotsArray.length; i++) {
              for (var j = 0; j < bSlots.length; j++){
                // console.log(bSlots[j].substring(1,bSlots[j].length));
                if(location == 'Electronic City'){

                  if(slotsArray[i] == bSlots[j]){

                    var id = "EC"+slotsArray[i];
                    console.log("-------"+id);
                    console.log(document.getElementById(id));
                    var myId = document.getElementById(id);
                    myId.src = '../images/yellow.png';
                    console.log("*********"+id);
                    break;
                  }
                  else{
                    console.log("I am Here.............");
                    // document.getElementById(id).src = '../images/blue.png';
                  }
                }
                else{
                  if(slotsArray[i] == bSlots[j]){
                    document.getElementById(location+slotsArray[i]).src = '../images/yellow.png';
                    console.log("*********"+slotsArray[i]);
                    break;
                  }else{
                    document.getElementById(location+slotsArray[i]).src = '../images/blue.png';
                  }
                }
                if(slotsArray[i] == bSlots[j]){
                  document.getElementById(slotsArray[i]).src = '../images/yellow.png';
                  console.log("*********"+slotsArray[i]);
                  break;
                }else{
                  console.log("hiii");
                  // document.getElementById(slotsArray[i]).src = '../images/blue.png';
                }
              }
            }
          })
     console.log("GCbfsbjfgsfgdfgdjbgfvdfgdjhfgdjhfgcjfgjdfbghegdg"+$scope.repeatData);
    }
})
